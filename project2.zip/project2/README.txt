README

To run: 

 - Naive Implementation:
	Type "python changeslow.py [filename].txt"
	
	Output will be put in a file called "[filename]change.txt"

 - Greedy Implementation:
	Type "python changegreedy.py [filename].txt"
	
	Output will be put in a file called "[filename]change.txt"

 - Dynamic Programming Implementation:
	Type "python changedp.py [filename].txt"
	
	Output will be put in a file called "[filename]change.txt"
